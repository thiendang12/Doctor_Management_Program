package view;
import controller.DoctorManagement;


public class Main {
    public static void main(String[] args) {
        DoctorManagement manager = new DoctorManagement();
        manager.run();
    }
}
